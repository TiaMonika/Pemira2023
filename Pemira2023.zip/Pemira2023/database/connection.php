<?php
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "dbpemira";

    $connect = mysqli_connect($host, $username, $password, $database);
?>
