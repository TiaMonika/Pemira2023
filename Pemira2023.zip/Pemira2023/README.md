- Color Pelette

- Hijau = #0A837E
- Oren = #FBB80C
- Kuning = #FED362
- Putih = #FDF3F1